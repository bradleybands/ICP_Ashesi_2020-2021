#include "recs.h"


    float cuboidBlocks::getWHL(){
      return wHL;
    }
    void cuboidBlocks::setWHL(float w){
      wHL = w;
    }
    void cuboidBlocks::cuboidBlocks_display()
   {
       cout << "Width, Height & Length: " << wHL<< "\n"<<endl;
   }
