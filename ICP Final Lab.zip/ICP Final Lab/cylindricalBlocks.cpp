#include "recs.h"



    //Mutators
    void   cylindricalBlocks::setDiameter(float diam){
      diameter = diam;
    }
    void   cylindricalBlocks::setLength(float len){
      length = len;
    }
    void   cylindricalBlocks::setArea(float a){
      area = a;
    }

    //Accessors
    float   cylindricalBlocks::getDiameter(){
      return diameter;
    }
    float   cylindricalBlocks::getLength(){
      return length;
    }
    float   cylindricalBlocks::getArea(){
      return area;
    }

     void   cylindricalBlocks::cylindricalBlocks_display()
     {
         cout << "Diameter: "<< diameter
          << "\nLength: "<< length << "\nArea: " << area <<"\n"<< endl;
     }
