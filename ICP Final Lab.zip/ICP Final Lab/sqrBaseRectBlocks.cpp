#include "recs.h"

  float sqrBaseRectBlocks::getLength(){
    return length;
  }
  void sqrBaseRectBlocks::setLength(float length){
    this->length = length;
  }

    float sqrBaseRectBlocks::getWH(){
      return wH;
    }


    void sqrBaseRectBlocks::setWH(float w){
      wH = w;
    }
    void sqrBaseRectBlocks::sqrBaseRectBlocks_display()
   {
       cout << "Width & Height: " << wH
            << "\nLength: " << length <<"\n\n"<< endl;
   }
