#include "recs.h"



int main() {
  /* code */
  float width;
  float height;
  float length;

  vector<rectBlocks> rectBA;
  vector<sqrBaseRectBlocks> sqrBaseRBA;
  vector<cuboidBlocks> cuboidBA;
  vector<cylindricalBlocks> cylindricalBA;
  vector<sphericalBlocks> sphericalBA;



  ifstream inFile;
  inFile.open("dataBlocks.dat", ios::in);

  while (inFile.good()) {
    inFile  >> width >> height >> length;
    if (!inFile.eof()) {
      rectBlocks tempRB;
      tempRB.setWidth(width);
      tempRB.setHeight(height);
      tempRB.setLength(length);

      rectBA.push_back(tempRB);
    }
  }

  float temp = 0;
  for(float i=0; i < rectBA.size(); i++){
    if(rectBA[i].getWidth() == rectBA[i].getHeight()){
      sqrBaseRectBlocks tempSQR;
      tempSQR.setWH(rectBA[i].getWidth());
      tempSQR.setLength(rectBA[i].getLength());

      sqrBaseRBA.push_back(tempSQR);
      // sqrBaseRBA[temp].display();
      temp++;
    } ;
  }


  float temp2 = 0;
  for(float i=0; i < sqrBaseRBA.size(); i++){
    if(sqrBaseRBA[i].getWH() == sqrBaseRBA[i].getLength()){
      cuboidBlocks tempCB;
      tempCB.setWHL(sqrBaseRBA[i].getWH());

      cuboidBA.push_back(tempCB);
      //cuboidBA[temp2].display();
      temp2++;
    } ;
  }


  float temp3 = 0;
  for(float i = 0; i < cuboidBA.size(); i++){
    sphericalBlocks tempSB;

    tempSB.setDiameter(cuboidBA[i].getWHL());
    tempSB.setVolume((4/3)*(22/7)* pow((tempSB.getDiameter()/2),3));
    tempSB.setSurface(4*(22/7)* pow((tempSB.getDiameter()/2),2));

    sphericalBA.push_back(tempSB);
    //sphericalBA[temp3].display();
    temp3++;

  }
  float temp4 = 0;
  for(float i = 0; i < sqrBaseRBA.size(); i++){
    cylindricalBlocks tempCB;

    tempCB.setDiameter(sqrBaseRBA[i].getWH());
    tempCB.setArea((2*(22/7)*tempCB.getDiameter()/2) + 2*(22/7)* pow(tempCB.getDiameter()/2, 2));
    tempCB.setLength(sqrBaseRBA[i].getLength());

    cylindricalBA.push_back(tempCB);
     // cylindricalBA[temp4].display();
    temp4++;

  }


// sort for sphericalBA

cout << "Sorting sphericalBlocks in ascending order of their diameters: "<<"\n"<<endl;
  sort(sphericalBA.begin(), sphericalBA.end(), CompareSphere);

  for(float i = 0; i < sphericalBA.size(); i++){
     sphericalBA[i].sphericalBlocks_display();
  }

// sort for cylindricalBA
cout << "Sorting cylindricalBlocks in ascending order of their cylindrical surface: "<<"\n"<<endl;

sort(cylindricalBA.begin(), cylindricalBA.end(), CompareCylinder);

for(float i = 0; i < cylindricalBA.size(); i++){
  cylindricalBA[i].cylindricalBlocks_display();
}










}
