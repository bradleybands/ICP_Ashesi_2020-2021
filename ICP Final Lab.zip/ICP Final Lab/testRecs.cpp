// code worked on by Bradley Deku and Amenoracking Amenreynolds 

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;


class rectBlocks{
  public:
    int width;
    int height;
    int length;
    rectBlocks(){
      width = 0;
      height = 0;
      length = 0;
    }

    rectBlocks(int, int, int);
//Accessors
    int getWidth(){
      return width;
    }
    int getHeight(){
      return height;
    }
    int getLength(){
      return length;
    }

    void display()
   {
       cout << "Width: " << width
            << " \nHeight: " << height
            << "\nLength: " << length <<"\n\n"<< endl;
   }

//Mutators
    void setWidth(int w){
      width = w;
    }
    void setHeight(int h){
      height = h;
    }
    void setLength(int l){
      length = l;
    }

};

rectBlocks::rectBlocks ( int w, int h,int l){
  width = w;
  height = h;
  length = l;
};


class sqrBaseRectBlocks : public rectBlocks {
  public:
    int wH;
    int getWH(){
      return wH;
    }

    void setWH(int w){
      wH = w;
    }
    void display()
   {
       cout << "Width & Height: " << wH
            << "\nLength: " << length <<"\n\n"<< endl;
   }
};

// Cuboid blocks

class cuboidBlocks : public sqrBaseRectBlocks{

  public:
    int wHL;
    int getWHL(){
      return wHL;
    }
    void setWHL(int w){
      wHL = w;
    }
    void display()
   {
       cout << "Width, Height & Length: " << wHL<< "\n"<<endl;
   }
  };


class cylindricalBlocks : public sqrBaseRectBlocks{
  private:
     float diameter;
     float length;
     float area;
  public:

    //Mutators
    void setDiameter(int diam){
      diameter = diam;
    }
    void setLength(float len){
      length = len;
    }
    void setArea(float a){
      area = a;
    }

    //Accessors
    int getDiameter(){
      return diameter;
    }
    float getLength(){
      return length;
    }
    float getArea(){
      return area;
    }

     void display()
     {
         cout << "Diameter: "<< diameter
          << "\nLength: "<< length << "\nArea: " << area <<"\n"<< endl;
     }
};

class sphericalBlocks : public cuboidBlocks{
public:
    int diameter;
    float volume;
    float surface;

    //Mutators
    void setDiameter(int diam){
      diameter = diam;
    }
    void setVolume(float vol){
      volume = vol;
    }
    void setSurface(float surf){
      surface = surf;
    }

    //Accessors
    int getDiameter(){
      return diameter;
    }
    float getVolume(){
      return volume;
    }
    float getSurface(){
      return surface;
    }

    void display()
    {
        cout << "Diameter: "<< diameter
          << "\nVolume : " << volume
          <<"\nSurface: " << surface <<"\n"<< endl;
    }
};

// sorting in ascending order of the diameter for sphericalBA
bool CompareSphere(sphericalBlocks sB1, sphericalBlocks sB2)
{
    if (sB1.getDiameter() > sB2.getDiameter())
        return false;
    return true;
}

// sorting in ascending order of the cylindrical surface area for cylindricalBA
bool CompareCylinder(cylindricalBlocks cB1, cylindricalBlocks cB2)
{
    if (cB1.getArea() > cB2.getArea())
        return false;
    return true;
}


int main() {
  /* code */
  int width;
  int height;
  int length;

  vector<rectBlocks> rectBA;
  vector<sqrBaseRectBlocks> sqrBaseRBA;
  vector<cuboidBlocks> cuboidBA;
  vector<cylindricalBlocks> cylindricalBA;
  vector<sphericalBlocks> sphericalBA;

  ifstream inFile;
  inFile.open("dataBlocks.dat", ios::in);

  while (inFile.good()) {
    inFile  >> width >> height >> length;
    if (!inFile.eof()) {
      rectBlocks tempRB;
      tempRB.setWidth(width);
      tempRB.setHeight(height);
      tempRB.setLength(length);

      rectBA.push_back(tempRB);
    }
  }

  int temp = 0;
  for(int i=0; i < rectBA.size(); i++){
    if(rectBA[i].width == rectBA[i].height){
      sqrBaseRectBlocks tempSQR;
      tempSQR.setWH(rectBA[i].width);
      tempSQR.setLength(rectBA[i].length);

      sqrBaseRBA.push_back(tempSQR);
      // sqrBaseRBA[temp].display();
      temp++;
    } ;
  }


  int temp2 = 0;
  for(int i=0; i < sqrBaseRBA.size(); i++){
    if(sqrBaseRBA[i].wH == sqrBaseRBA[i].length){
      cuboidBlocks tempCB;
      tempCB.setWHL(sqrBaseRBA[i].wH);

      cuboidBA.push_back(tempCB);
      //cuboidBA[temp2].display();
      temp2++;
    } ;
  }


  int temp3 = 0;
  for(int i = 0; i < cuboidBA.size(); i++){
    sphericalBlocks tempSB;

    tempSB.setDiameter(cuboidBA[i].getWHL());
    tempSB.setVolume((4/3)*(22/7)* pow((tempSB.getDiameter()/2),3));
    tempSB.setSurface(4*(22/7)* pow((tempSB.getDiameter()/2),2));

    sphericalBA.push_back(tempSB);
    //sphericalBA[temp3].display();
    temp3++;

  }
  int temp4 = 0;
  for(int i = 0; i < sqrBaseRBA.size(); i++){
    cylindricalBlocks tempCB;

    tempCB.setDiameter(sqrBaseRBA[i].getWH());
    tempCB.setArea((2*(22/7)*tempCB.getDiameter()/2) + 2*(22/7)* pow(tempCB.getDiameter()/2, 2));
    tempCB.setLength(sqrBaseRBA[i].getLength());

    cylindricalBA.push_back(tempCB);
     // cylindricalBA[temp4].display();
    temp4++;

  }


// sort for sphericalBA
cout << "Sorting sphericalBlocks in ascending order of their diameters: "<<"\n"<<endl;
  sort(sphericalBA.begin(), sphericalBA.end(), CompareSphere);

  for(int i = 0; i < sphericalBA.size(); i++){
     sphericalBA[i].display();
  }


// sort for cylindricalBA
cout << "Sorting cylindricalBlocks in ascending order of their cylindrical surface: "<<"\n"<<endl;

sort(cylindricalBA.begin(), cylindricalBA.end(), CompareCylinder);

for(int i = 0; i < cylindricalBA.size(); i++){
  cylindricalBA[i].display();
}






}
