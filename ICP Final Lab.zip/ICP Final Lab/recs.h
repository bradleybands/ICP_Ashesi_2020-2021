
#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;


class rectBlocks{
private:
  float width;
  float height;
  float length;
  public:


//Accessors
    float getWidth();


    float getHeight();

    float getLength();


    void rectBlocks_display();




//Mutators
    void setWidth(float w);

    void setHeight(float h);


    void setLength(float l);


};




class sqrBaseRectBlocks : public rectBlocks {
private:
  float wH;
  float length;

  public:

    float getWH();

    void setWH(float w);

    float getLength();
    void setLength(float length);


    void sqrBaseRectBlocks_display();



};

// Cuboid blocks

class cuboidBlocks : public sqrBaseRectBlocks{
private:
  float wHL;

  public:

    float getWHL();

    void setWHL(float w);


    void cuboidBlocks_display();



  };


class cylindricalBlocks : public sqrBaseRectBlocks{
  private:
    float diameter;
    float length;
    float area;

  public:

    //Mutators
    void setDiameter(float diam);


    void setLength(float len);


    void setArea(float a);



    //Accessors
    float getDiameter();

    float getLength();

    float getArea();


     void cylindricalBlocks_display();




};
bool CompareCylinder(cylindricalBlocks &cB1, cylindricalBlocks &cB2)
{
    if (cB1.getArea() > cB2.getArea())
        return false;
    return true;
}



class sphericalBlocks : public cuboidBlocks{
private:

  float diameter;
  float volume;
  float surface;

public:

    //Mutators
    void setDiameter(float diam);

    void setVolume(float vol);

    void setSurface(float surf);


    //Accessors
    float getDiameter();

    float getVolume();

    float getSurface();


    void sphericalBlocks_display();



};
bool CompareSphere(sphericalBlocks &sB1, sphericalBlocks &sB2)
  {
      if (sB1.getDiameter() > sB2.getDiameter())
          return false;
      return true;
  }
