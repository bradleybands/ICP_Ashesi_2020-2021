#include "recs.h"


    //Mutators
    void sphericalBlocks:: setDiameter(float diam){
      diameter = diam;
    }
    void   sphericalBlocks::setVolume(float vol){
      volume = vol;
    }
    void   sphericalBlocks::setSurface(float surf){
      surface = surf;
    }

    //Accessors
    float   sphericalBlocks::getDiameter(){
      return diameter;
    }
    float   sphericalBlocks::getVolume(){
      return volume;
    }
    float   sphericalBlocks::getSurface(){
      return surface;
    }

    void  sphericalBlocks::sphericalBlocks_display()
    {
        cout << "Diameter: "<< diameter
          << "\nVolume : " << volume
          <<"\nSurface: " << surface <<"\n"<< endl;
    }
