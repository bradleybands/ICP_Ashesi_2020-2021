#include "recs.h"


//Accessors
float rectBlocks::getWidth(){
  return width;
}
float rectBlocks::getHeight(){
  return height;
}
float rectBlocks::getLength(){
  return length;
}

void rectBlocks::rectBlocks_display()
{
   cout << "Width: " << width
        << " \nHeight: " << height
        << "\nLength: " << length <<"\n\n"<< endl;
}

//Mutators
void rectBlocks::setWidth(float w){
  width = w;
}
void rectBlocks::setHeight(float h){
  height = h;
}
void rectBlocks::setLength(float l){
  length = l;
}
